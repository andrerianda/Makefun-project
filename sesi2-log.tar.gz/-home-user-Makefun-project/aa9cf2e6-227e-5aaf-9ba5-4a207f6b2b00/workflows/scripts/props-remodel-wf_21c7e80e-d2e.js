export const meta = {
  name: 'props-remodel',
  description: 'Remodel the 27 street props of CAMPANILE in the model-kit text format, fitted to their collision boxes',
  phases: [
    { title: 'Model', detail: 'one modeller per prop group writes its models to a private file' },
    { title: 'Critique', detail: 'an independent critic renders and measures each group' },
    { title: 'Revise', detail: 'the modeller fixes what the critic found' },
  ],
}

const COMMON = `
You are a 3D prop artist on CAMPANILE, a 5v5 tactical FPS built on three.js, set in an ORIGINAL pastel Mediterranean harbour town ("Porto Vesper") at dusk. Every model is plain text in a tiny "model kit" format that the game bakes into meshes at load. You will hand-write models (no generators, no copying from anywhere: write every line yourself with the Write/Edit tools, because the bounty checks that the work is in the session transcripts). Do not use names of commercial games.

## The format (game/src/render/kit.js reads it; read that file, it is 57 lines)
  @ name                                   starts a model (a later "@ name" with the same name overrides an earlier one)
  > bone parent x y z                      a bone placed in its parent's space ('-' for the root). Static props use ONE bone: "> root - 0 0 0"
  b|c|s|k|n  w h d  x y z  rx ry rz  #rrggbb   a part on the last bone
     b box: width w (x), height h (y), depth d (z)
     c cylinder: top DIAMETER w, height h, bottom DIAMETER d, 12 radial segments (axis along y before rotation)
     s sphere: a unit-diameter sphere scaled to diameters w,h,d (14x10 segments)
     k capsule: diameter w, straight length h (total length h+w), axis y
     n cone: base diameter w, height h, apex up (+y), 10 segments
  x y z = the part's centre in bone space; rx ry rz = Euler XYZ rotation in radians applied to the part about its centre.
Axes: forward is -z, up +y, right +x, metres. Colours are flat vertex colours under Lambert lighting (hemisphere + low warm sun + fog); there are NO textures on props, so the look comes from silhouette, facets and colour variation: use 2-3 close tones per material (planks alternating #7a5334 / #8a633f / #6b4a34, plaster stone #9c8f86 / #b9ac98, iron #2b2f36 / #3a3f45, terracotta #b5533a / #c46a4a, canvas #efe6d6 / #d8cdb8, saffron #f2a23a, teal #35b8ad, rope #cbbfa8, sea-green paint #6f9bb0 / #2f6f66, oxblood #7a3b2e) and small honest details (iron hoops, rims, rope, nails, handles, slats) - "carefully styled geometry" that reads at a glance from 5-15 m. Dusk pastel palette (game/src/config.js PALETTE): stucco #e8b98c #d98f6f #e6d3a8 #b9cfc0 #c9a0a8 #dcc48a, shutters #2f6f66 #7a3b2e #31507a #3d5a34. Avoid pure/neon colours and avoid near-black except iron.

## Cost (every static prop is merged into ONE mesh, non-indexed; keep it lean)
Vertices per part: box 36, cylinder 144, cone ~90, capsule ~600, sphere ~760. Prefer boxes and cylinders; use spheres/capsules sparingly. Budgets per model given below; stay under them.

## Your tools (dev servers already running; Chromium headless with SwiftShader, 4 shared CPUs: be patient, run one render at a time)
  Preview, models side by side with optional green wireframe collision boxes (square footprint WxW, height H):
    node /home/user/Makefun-project/tools/kitshot.mjs /root/makefun/shots/<you>-x.jpg "m=a,b&box=1.5x1.3,1x0.8&d=6&h=1.5&gap=2.6&yaw=0.6&extra=/root/makefun/props/<group>.txt" [w h]
      d = camera distance, h = camera height, gap = spacing, yaw = model turn, look = aim height factor. Then Read the jpg to look at it.
      Render several yaws (0, 0.8, 1.6, 3.14) and a high view (h=3) - check every side.
  Fit, how the model fills its collision box (orthographic silhouettes at 1 px/cm, measured below CLIP metres):
    CLIP=2 node /home/user/Makefun-project/tools/fit.mjs "cart=1.5x1.3,fountain=1.9x0.7+0.5x1.9" /root/makefun/props/<group>.txt
      fill = share of the box projection covered (front, side, top); out = m^2 of silhouette OUTSIDE the footprint below CLIP; over = m^2 inside the footprint but above the box top; bbox = model bounds.
  In-game: make a private copy of the game once, append your models to its props file (later definitions override), and take screenshots at map cells:
    mkdir -p /root/makefun/work/<group> && cp -r /home/user/Makefun-project/game /root/makefun/work/<group>/   (re-copy props: cp /home/user/Makefun-project/game/assets/props.txt /root/makefun/work/<group>/game/assets/props.txt && cat /root/makefun/props/<group>.txt >> /root/makefun/work/<group>/game/assets/props.txt)
    BASE=http://localhost:8127/root/makefun/work/<group>/game QUERY='index.html?sharp=1&watch=1&seed=3' W=960 H=540 node /home/user/Makefun-project/tools/tour.mjs <group>-name:col:row:yaw:pitch [more specs...]
      writes /root/makefun/shots/<group>-name.jpg (~20 s each). col,row are map cells (fractions ok; a cell is 2 m). yaw 0 looks north (-z), pi/2 west (-x), -pi/2 east (+x), pi south (+z); pitch negative looks down. The HUD covers the corners; frame the prop in the centre. The map is ASCII in game/src/sim/map.js (read it).
  Prop placement rules are in game/src/render/level.js (read buildLevel's prop() calls) and sizes in game/src/sim/map.js PROPS.

## Hard rules
- Write ONLY your own file /root/makefun/props/<group>.txt (and scratch files under /root/makefun/). Do NOT edit anything under /home/user/Makefun-project: other artists work in parallel and the lead merges your file.
- Each model: a one-line "# ..." comment above its "@ name" saying what it is, then "> root - 0 0 0" (plus other bones only where stated), then parts. Keep the exact model names given.
- Numbers with at most 3 decimals; one part per line; a blank line between models.
- Shots you write go to /root/makefun/shots/ prefixed with your group name.
`

const OBSTACLE_RULES = `
## Obstacle fit (the owner's complaint: "obstacles must be perfect")
The simulation stops players and bullets with an axis-aligned BOX: a square footprint W x W centred on the model origin, from y=0 to height H. The level turns the model by a random quarter turn, so design for the whole square, every side.
- HARD: nothing solid-looking outside the footprint below 2.0 m: fit "out" <= 0.02 on front, side and top (2 cm tolerance). A player walks through anything outside the box, so it must not be there.
- The model must read as filling the box: aim for front and side fill >= 0.85 and top fill >= 0.75. Big see-through gaps inside the box look like invisible walls (players and bullets stop on the whole box). Fill the volume with honest stuff (a pallet under sacks, side boards, a tarp, a tablecloth, stacked goods, chocks), not with an anonymous cube.
- The main mass tops out at H (within 3 cm). Above H only thin or open things (posts, a canopy, an umbrella, a spout, foliage), and keep "over" small below 2 m - bullets fly through anything above the box.
- It must still read instantly as the named object from 10 m away.
`

const GROUPS = [
  {
    key: 'g1', title: 'market obstacles',
    brief: `${OBSTACLE_RULES}
Your models (collision box W x H; where they stand; how many):
- stall (1.7 x 1.0): a fish-market stall, 6 of them in the Fish Market (cells (4,2) (7,2) (4,4) (7,9) (4,10) (7,10)). Counter fills the box to 1.0 m; four slim posts and a striped canvas canopy above (the canopy may overhang above 2.0 m); a little goods on the counter (fish on ice, a scale, a crate of lemons) kept low. Budget 4000 verts.
- table (1.0 x 0.8): a cafe table in Bell Square (cells (15,6) (24,6)), 2 of them. Fill the box honestly (e.g. a cloth to the ground, chairs tucked in) with a parasol above head height (above 2.1 m). Budget 3500 verts.
- fountain (basin 1.9 x 0.7 PLUS a centred spout box 0.5 x 1.9): the Fish Market fountain at cell (4,6), 1 of them. Square or octagonal stone basin filling the 1.9 square with a rim and teal water just under the rim; a column inside the 0.5 square up to ~1.9 m with a small bowl/finial; thin pale water streams allowed. Use fit spec "fountain=1.9x0.7+0.5x1.9". Budget 5000 verts.
- cypress: stands ON TOP of a 1.5 x 1.5 x 0.8 stone planter box that the level draws itself (cells (16,5) (23,5)); the model's y=0 is the planter's top. Collision is only the planter, so the tree is free above; but below 1.2 m model-space (2 m world) keep everything inside the 1.5 square: check with CLIP=1.2 and box "cypress=1.5x0.01". Soil, a low clipped hedge or flowers at the rim, and a tall slender Italian cypress (3.5-4.5 m) built from stacked tapered cylinders/cones in 2-3 greens. Budget 3500 verts.
In-game views: Fish Market from (6,7.5) yaw 1.2 pitch -0.15, and (8,3) yaw 2.3; Bell Square tables/planters from (20,6) yaw 1.3 and yaw -1.3, pitch -0.1.`,
  },
  {
    key: 'g2', title: 'harbour obstacles',
    brief: `${OBSTACLE_RULES}
Your models (collision box W x H; where; how many):
- barrels (1.2 x 1.1): a cluster of coopered barrels, 1 placed (cell (4,20), Net Row) - make it the best-looking prop in the game: bulging staves (two cylinders per barrel, wider in the middle), iron hoops, lids, maybe one small keg on top kept within H. Budget 4000 verts.
- cart (1.5 x 1.3): a two-wheeled handcart with its load, 4 placed (cells (12,6) (24,9) (34,16) (6,25)). EVERYTHING inside the 1.5 square, handles/shafts included (the old one stuck 0.85 m out). Big spoked-looking wheels (a cylinder rim + hub + crossed thin boxes), side boards, a load (crates, sacks, a tarp) up to 1.3 m. Budget 5000 verts.
- nets (1.4 x 1.0): a heap of fishing nets with cork floats and rope over a crate or drum, 3 placed on the quay and in the Boathouse (cells (34,4) (35,13) (31,20)). Budget 4000 verts.
- sacks (1.3 x 0.9): sacks piled on a wooden pallet that fills the footprint, 2 placed (cells (27,4) (32,25)). Budget 4000 verts.
- hull (1.8 x 1.5): "a boat hull on stocks" in the Boathouse boatyard, 2 placed (cells (31,1) (34,6)). The old model was a 3.4 m hull sticking 1.7 m out of its 1.8 m box: the WHOLE thing must now fit the 1.8 square. Think of a short beamy dinghy or a boat's bow section under construction on timber stocks/trestles, ribs showing, with planks or a tarp filling out the sides so the box reads solid. Budget 5000 verts.
In-game views: Net Row barrels from (4,17) yaw 0 pitch -0.15; carts from (14,6) yaw 1.6 and (6,23) yaw 0; Boathouse from (31,7.5) yaw 0.3 pitch -0.1 (hulls, nets, sacks); quay from (34,11) yaw 3.14.`,
  },
  {
    key: 'g3', title: 'wall-foot dressing',
    brief: `
These stand at the FOOT OF HOUSE WALLS, one per window bay (bays are 2.4 m apart along the wall). The model's z=0 plane is the wall face and +z points out into the street (the level turns it to face away from its wall). They have NO collision, so the player must never be able to walk into them: keep every part within z in [0, 0.34] (the player body radius is 0.36 m). Stay within x in [-0.7, 0.7] (except pipe), on y >= 0, nothing below the ground. Nothing may poke behind the wall (z < 0) more than 1 cm.
Your models (budget each 2500 verts unless stated):
- pots: terracotta flower pots with geraniums/herbs against the wall (placed 6x).
- anchor: an old iron anchor leaning against the wall, maybe with a coil of rope (6x).
- lobsterpots: stacked wicker/slatted lobster pots with a float or two (7x).
- pipe: a cast-iron drainpipe from the gutter (~6.0 m) down the wall, with brackets, a hopper head at the top and a shoe at the foot (9x). Within z [0, 0.2], width <= 0.4. Budget 1500.
- bench: a slatted wooden bench against the wall, seat 0.45 m (new placement, ~6x).
- fishcrate: two or three stacked fish crates with ice and fish on top, against the wall (new placement, ~6x).
- crates: a small stack of wooden crates (e.g. one 0.6 m crate with a smaller on top, slats/nails), against the wall (new placement, ~6x).
- signpost: a wrought-iron wall bracket at ~2.3-2.6 m holding a hanging painted shop board (a fish or a bottle shape painted on in colour blocks), projecting at most 0.7 m from the wall and nothing below 2.2 m except a flat plate on the wall (new placement, ~6x). This one may go out to z 0.7 because it is above head height.
In-game: walls line every lane; e.g. Net Row from (4.5,14) yaw 0 pitch -0.2 and yaw 3.14, Bell Lane from (19.5,16) yaw 0, Low Road from (10,25) yaw -1.57. Your new placements are not in the game yet, so to see them in situ, temporarily rename them in your private copy (e.g. append a copy of your bench model named "pots") and take a shot; never edit the repo.`,
  },
  {
    key: 'g4', title: 'walls, roofs and lamps',
    brief: `
Your models hang on house walls, sit on roofs or light the lanes. A wall-mounted model's z=0 plane is the wall face and +z points into the street. No collision on any of these.
- awning (49 placed): over a ground-floor door. The level paints a door decal 1.5 m wide and 2.3 m tall (y 0 to 2.3) on the wall at the model's origin, and places this model at y=0. A striped canvas shop awning: starts on the wall at ~2.55 m, slopes down outward to no lower than 2.25 m, projects 0.8-0.9 m, ~1.8 m wide, a scalloped or fringed valance, two slim iron arms. Colours vary by stripe pairs you choose (2 tones), they're baked identical for all 49, so choose a pleasing pair (e.g. oxblood/canvas or teal/canvas). Budget 1500 verts.
- balcony (31 placed): under an upper-floor window. The level places it at y = 5.6 on the wall; the window decal above it is 1.5 m wide and spans y 5.7 to 7.4 (i.e. model-space 0.1 to 1.8). A stone slab ~1.7 x 0.5 deep with corbels under it, a wrought-iron railing (0.9 m high), a flower box with geraniums. Budget 2500 verts.
- washing (13 placed): placed at y=0 on the wall; a washing line on two iron brackets at ~4.2 m, 0.4-0.5 m out from the wall, 2.4-3 m wide, with laundry hanging (shirts, sheets, a striped towel) in pastel colours. Budget 2500 verts.
- chimney (68 placed): on house roofs; placed at the roof's top (model y=0 is just above the roof slab). A stucco chimney stack ~0.5-0.6 square, ~0.9-1.2 tall, with a projecting brick cap and one or two terracotta pots or a little roof-tile hood. Budget 700 verts.
- bunting (~30 placed): strung across lanes at 5.5 m; model y=0 is the line, a 4.0 m straight segment along x (x -2 to 2). Pennants hang below (max 0.45 m), alternating saffron #f2a23a, teal #35b8ad, canvas #efe6d6, oxblood #c7503a; flat triangles (e.g. thin boxes or cones squashed thin in z). Budget 900 verts.
- lamp (9 placed): a street lamp at the foot of a wall (origin 0.08 m from the wall face; its arm reaches toward +x, into the lane; the level turns it). Either a slender cast-iron post with a scrolled arm, or a wall bracket - lantern head at about 3.0-3.3 m. It MUST keep a second bone named glow: "> glow root x y z" positioned at the lantern's light, carrying the bright warm glass (#ffe2b0 / #fff0c0) - the level puts a haze sprite at the glow bone's world position. Budget 3000 verts. The post's footprint must stay within 0.3 m of the wall (players do not collide with it).
In-game: Net Row from (4.5,14) yaw 0 pitch 0.25 (balconies, washing), Bell Lane from (19.5,20) yaw 0 pitch 0.1, the Low Road from (20,25) yaw 1.57, the Fish Market from (8,8) yaw 0.6 pitch 0.1. Roofs: from a corner looking up (pitch 0.4).`,
  },
  {
    key: 'g5', title: 'harbour and landmark',
    brief: `
- boat (2 placed, afloat beside the quay, the level bobs them): a small wooden fishing boat with a mast and furled sail, ~3.8 m long along z, ~1.5 m beam. The sea surface sits at model y = -0.08: the hull's waterline is there (hull bottom ~ -0.45, gunwale ~ +0.55). Painted planking (two colours + a stripe), thwarts, a little cuddy or net pile, a mast ~3.3 m with a furled sail on a yard or boom. Budget 7000 verts.
- rowboat (1 placed, afloat): a small rowing boat ~2.6 m long, ~1.1 m beam, same waterline (y = -0.08), two thwarts and a pair of oars shipped inside. Budget 4000 verts.
- bollard (4 placed): a cast-iron mooring bollard on top of the 1.1 m sea wall (model y=0 is the wall top; the wall is 2 m thick, so stay within 0.4 m of the origin), ~0.55-0.65 tall with a mushroom cap and maybe a rope loop. Budget 1200 verts.
- bell (1 placed): the great bronze bell of the campanile, the landmark seen from every lane. Model origin is the centre of the belfry floor at 20.6 m. The belfry is open: four corner pillars 0.6 x 0.6 rising from local y -0.6 to +2.6 at the corners of a 4.12 m square (pillar inner faces at x,z = +-1.46); between them it's open air. Hang the bell (mouth ~1.3 m diameter, ~1.3 m tall, flared lip, crown, bronze #9a7438 / #7d5e2c, a green verdigris tint #6f8a6a on the shoulder) from a timber headstock on a beam running between two opposite pillars at ~2.2 m (the beam may run from x -1.46 to +1.46). Budget 5000 verts.
In-game views: the quay from (34,12) yaw -1.9 pitch -0.15 and (34,19) yaw -1.4 (boats, bollards); the bell from (19.5,15) yaw 0 pitch 0.42 and from (19.5,3) yaw 3.14 pitch 0.45.`,
  },
]

const SUMMARY = {
  type: 'object',
  properties: {
    file: { type: 'string' },
    models: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, verts: { type: 'number' }, fit: { type: 'string' }, notes: { type: 'string' } }, required: ['name', 'notes'] } },
    shots: { type: 'array', items: { type: 'string' } },
    open_issues: { type: 'array', items: { type: 'string' } },
  },
  required: ['file', 'models', 'open_issues'],
}
const CRITIQUE = {
  type: 'object',
  properties: {
    verdict: { type: 'string', enum: ['ship', 'revise'] },
    issues: { type: 'array', items: { type: 'object', properties: { model: { type: 'string' }, severity: { type: 'string', enum: ['high', 'medium', 'low'] }, problem: { type: 'string' }, fix: { type: 'string' } }, required: ['model', 'severity', 'problem', 'fix'] } },
  },
  required: ['verdict', 'issues'],
}

const results = await pipeline(
  GROUPS,
  (g) => agent(`${COMMON}
## Your group: ${g.key} (${g.title}). Your file: /root/makefun/props/${g.key}.txt
${g.brief}

Look at the current placeholder versions in /home/user/Makefun-project/game/assets/props.txt (and the finished figures/weapons in kit.txt for the house style), then model each prop properly. Iterate: write, preview from several angles, measure with fit (obstacles), view in game, fix. Do at least two in-game views. Count vertices by hand from the part counts and stay in budget. When done, return the summary (file path, per-model vertex estimate, final fit numbers where relevant, the shots you took, and anything still not right).`, { label: `model:${g.key}`, phase: 'Model', schema: SUMMARY }),
  (sum, g) => agent(`${COMMON}
## You are the CRITIC for group ${g.key} (${g.title}). The modeller's file: /root/makefun/props/${g.key}.txt
${g.brief}

The modeller reports: ${JSON.stringify(sum)}

Do NOT edit their file. Independently verify it against every requirement above: read the file, render each model from at least 4 yaws and one high view, run fit where it applies, take in-game shots (make your own private copy /root/makefun/work/${g.key}-critic). Check: does each read instantly as the named object at game distance; proportions against a 1.82 m player; fit numbers (out <= 0.02 is a hard rule for obstacles); parts poking through each other or floating; z-fighting coplanar faces; colours harmonious with the dusk palette; nothing below ground or behind the wall; vertex budget (count parts: box 36, cylinder 144, cone 90, capsule 600, sphere 760); syntax (each part line has exactly 11 fields; a bad line silently vanishes). Return verdict "ship" only if nothing medium or high remains; list concrete, actionable fixes with numbers.`, { label: `critic:${g.key}`, phase: 'Critique', schema: CRITIQUE }),
  (crit, g, i) => crit && crit.verdict === 'ship' && !crit.issues.some((x) => x.severity !== 'low')
    ? { group: g.key, critique: crit, final: null }
    : agent(`${COMMON}
## Your group: ${g.key} (${g.title}). Your file: /root/makefun/props/${g.key}.txt (you wrote it in an earlier pass)
${g.brief}

An independent critic reviewed your models and found:
${JSON.stringify(crit)}

Fix every high and medium issue (and the low ones where cheap), re-render, re-measure, re-check in game. Return the final summary.`, { label: `revise:${g.key}`, phase: 'Revise', schema: SUMMARY }).then((final) => ({ group: g.key, critique: crit, final })),
)
return results
