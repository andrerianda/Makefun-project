export const meta = {
  name: 'v2-review',
  description: 'Thorough read-only review of CAMPANILE v2: judge rubric, sim, bots, client, code quality, byte budget, gate and mobile; adversarially verified',
  phases: [
    { title: 'Find', detail: 'one reviewer per dimension' },
    { title: 'Verify', detail: 'skeptics try to refute each medium+ finding' },
  ],
}

const CONTEXT = `
You are reviewing CAMPANILE, a 5v5 round-based tactical FPS on three.js 0.187.0 entered in the make.fun bounty "threejs-fps-02". Repo: /home/user/Makefun-project. READ-ONLY: do not edit, create or delete anything under /home/user/Makefun-project; put any scratch scripts under /root/makefun/review/ (mkdir -p it). Dev servers are running: game at http://localhost:8124 (node tools/serve.mjs game 8124), repo root at :8125, filesystem root at :8127. Chromium headless (SwiftShader) is slow and the box has 4 shared CPUs: run browser tools one at a time.

Layout: game/index.html, game/src/main.js (fixed 60 Hz sim + interpolated render), game/src/config.js, game/src/sim/* (pure simulation, runs in Node: one state object, event ring emit/drain), game/src/render/* (three.js), game/src/ui/*, game/src/audio.js (WebAudio synth), game/src/input.js, game/assets/*.txt (model kit data, read by render/kit.js), mobile/ (touch test page, outside the entry), main.ts (hand-in: copies game/ and screenshots/, writes the dossier via vendor/makefun-threejs.ts), tools/*.mjs (dev tools, outside the entry). HANDOFF.md has the project notes.

Dev tools: node tools/simtest.mjs 1 2 3 (headless bot matches); FULL=1 node tools/balance.mjs 32; node tools/errs.mjs (load game, print errors); node tools/soak.mjs 7 (a full match in the browser); node tools/deadcode.mjs; W=960 H=540 node tools/tour.mjs name:col:row:yaw:pitch (screenshot to /root/makefun/shots/); node tools/scene.mjs out.jpg <seed> <seconds> "<js predicate (s, a)>" 1280 720. URL flags: ?sharp=1 ?watch=1 (bots play) ?level=0..2 ?seed=N. window.campanile = { state, hud, hold, skip(seconds) } in the page.

The judge is an AI that does NOT run the game: it reads 3-4 screenshots plus at most 163,840 bytes of source text (the dossier: out/dossier.json "text", built by "mkdir -p out && MAKEFUN_OUTPUT_DIR=out node main.ts"): index.html, then the JS modules in import order from src/main.js, then style.css last (currently cut off entirely). Rubric in order: (1) a complete game, (2) gunplay and movement, (3) tactics, (4) map and look ("its own art or carefully styled geometry", "reads at a glance"), (5) code: one job per module, fixed-step sim separate from render, no per-frame allocation, state in one place, no duplication or dead code. JS+HTML is ~160.9 KB: there are only ~200 bytes of headroom before the last JS module gets cut, so EVERY fix must state its byte cost and any addition must be paid for by a saving.

Hard constraints (breaking one rejects the entry): never change game/vendor/, vendor/makefun-threejs.ts, LICENSE, .makefun/owner.json, the README badges, or the single import map in game/index.html; no code or assets copied from outside; no CDN/external URLs; no other three.js addons; no npm packages; main.ts standard library only; every game file inside game/ with relative references.
`

const FINDINGS = {
  type: 'object',
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          severity: { type: 'string', enum: ['critical', 'high', 'medium', 'low'] },
          file: { type: 'string' },
          line: { type: 'number' },
          evidence: { type: 'string', description: 'code quoted, a repro command and its output, or a screenshot path' },
          fix: { type: 'string', description: 'the concrete change, as code where possible' },
          byte_delta: { type: 'number', description: 'estimated change in judged JS/HTML bytes (negative saves)' },
        },
        required: ['title', 'severity', 'file', 'evidence', 'fix', 'byte_delta'],
      },
    },
    notes: { type: 'string' },
  },
  required: ['findings'],
}

const DIMENSIONS = [
  { key: 'judge', prompt: `Act as the bounty's AI judge. Build the dossier (mkdir -p /root/makefun/review/judge && MAKEFUN_OUTPUT_DIR=/root/makefun/review/judge node /home/user/Makefun-project/main.ts), read its "text" field in full and look at the four screenshots in /home/user/Makefun-project/screenshots/ (they are from v1 and will be retaken). Score each rubric criterion 1-10 with reasons, then list the changes that would raise the score most, as findings (severity = expected impact on the score). Include what in the code would make a judge doubt a criterion (misleading comments, a missing feature it cannot see in the code, an awkward module, a confusing name), and what the 4 new screenshots should show to prove each criterion. Put the scores in notes.` },
  { key: 'sim', prompt: `Hunt real bugs in the simulation: game/src/sim/{state,step,world,movement,weapons,damage,grenades,keg,economy,loadout,round}.js and config.js. Movement (collision, stairs/jumps, crouch, sticking, tunnelling at speed), weapons (spread, recoil, fire rate, reload edge cases, wall-bang through soft props, headshots/hitboxes), damage/armour, grenades (bounce, flash facing, smoke blocking sight), the keg (plant/douse rules, timers, carrier death, dropped keg), economy (pay, loss bonus, buy window, carrying over at half-time), rounds (win conditions, half-time swap, match end, draws, 12-round cap), the rifle pickup. Write Node scripts under /root/makefun/review/sim/ that import the sim modules directly (see tools/simtest.mjs for how) to reproduce each bug. Only report what you can demonstrate or quote precisely.` },
  { key: 'bots', prompt: `Hunt bugs and weaknesses in the bots: game/src/sim/{coach,bots,nav,perception}.js. Stuck or oscillating bots, bots shooting through walls or smoke, nav failures, bad rotations, never planting/dousing, radio spam, unfair aim, bots ignoring the human player, team-kill, behaviour when the human is dead or idle, difficulty levels (?level=0..2). Run many seeds headless (node tools/simtest.mjs 1 2 3 4 5 6 7 8 and FULL=1 node tools/balance.mjs 32) and write instrumented scripts under /root/makefun/review/bots/ (e.g. detect a bot that has not moved for 10 s while alive in a live round, or rounds that end on time with no plant). Report with reproductions.` },
  { key: 'client', prompt: `Hunt bugs in the client: game/src/main.js, render/*.js (view, level, sky, actors, effects, viewmodel, textures, kit), ui/*.js (hud, radar, panels), audio.js, input.js, index.html, style.css. Look for per-frame allocations (new objects/arrays/strings/closures inside frame/update paths), leaks (geometry/material not disposed, listeners piling up, DOM nodes growing), wrong interpolation, z-fighting, HUD states that never clear, pointer-lock edge cases, buy menu input, scope overlay, audio nodes never stopped, WebAudio started before a gesture, tab-visibility. Use node tools/errs.mjs, node tools/soak.mjs 7 and tour/scene screenshots; Read the screenshots. Report with evidence.` },
  { key: 'quality', prompt: `Review code quality exactly as the rubric's criterion (5) states: one job per module, the fixed-step sim separate from render, no per-frame allocation, state in one place, no duplication or dead code. Run node tools/deadcode.mjs. Find duplicated logic across modules (e.g. two ray casts, two copies of a hash, repeated vector math), dead exports/config keys/branches/parameters, functions that do two jobs, state kept outside the state object, comments that lie or describe old behaviour, unclear names. Note: audio.js exports createSynth only for a test - flag it. For each, give the exact fix and its byte delta.` },
  { key: 'bytes', prompt: `Find byte savings in the judged text (index.html + all JS in game/src), target at least 4 KB in total, WITHOUT hurting readability or the code-quality criterion, and without changing behaviour. Ideas to evaluate: move geometry that render/level.js builds in code (the campanile tower: shaft, corner pillars, cornices, roof, spire cone, clock faces) into model-kit data in game/assets/land.txt (assets are free: the judge does not read them); move other hard-coded data tables (e.g. long arrays of numbers, coordinate lists, text strings) into assets/*.txt or JSON is NOT free (.json is source) - only .txt is an asset; tidy index.html markup; shorten over-long comments that restate the code (keep the ones that explain intent); remove duplicate helpers. For each opportunity: file, lines, the exact proposed replacement (or for an asset move: the new asset lines and the new loading code), measured byte delta (count it: wc -c), and the risk. Check how the asset files are loaded (render/kit.js loadKit, main.js) before proposing new asset loading.` },
  { key: 'gate', prompt: `Check gate compliance and the mobile page. (a) Build the dossier (mkdir -p /root/makefun/review/gate && MAKEFUN_OUTPUT_DIR=/root/makefun/review/gate node /home/user/Makefun-project/main.ts) and confirm: index.html has exactly one <script type="importmap"> mapping "three" to ./vendor/three/three.module.min.js; every reference in index.html and every import in game/src is relative and resolves inside game/; no http(s):// or // URLs anywhere in game/ (outside vendor) - grep; no fetch of anything outside game/; game/vendor/three/ holds three.module.min.js and three.core.min.js of three.js 0.187.0 (check the version string inside) and LICENSE; README.md has the make.fun badge; LICENSE has an SPDX line; .makefun/owner.json exists; game/ under 993 files and 48 MiB; screenshots/ has 3-4 PNG/JPEG each <= 256 KiB with long side <= 1280 and short side >= 480 (use 'file'). Also grep the whole repo and its git history for anything that looks like a secret (API keys, private keys, keypair JSON, tokens): git log -p | grep -iE 'secret|api[_-]?key|BEGIN .*PRIVATE|keypair|token' (report only real hits). (b) mobile/: read mobile/index.html and mobile/touch.js and run node tools/mobiletest.mjs if it exists; check the touch page still works with the v2 game (new keys Z/X/G radio, V camera, weapon pickup, scope). Report problems with evidence.` },
]

const VERDICT = {
  type: 'object',
  properties: {
    refuted: { type: 'boolean' },
    reason: { type: 'string' },
    corrected_fix: { type: 'string', description: 'if the finding is real but the proposed fix is wrong or costs too many bytes, a better fix' },
  },
  required: ['refuted', 'reason'],
}

const results = await pipeline(
  DIMENSIONS,
  (d) => agent(`${CONTEXT}\n## Your dimension: ${d.key}\n${d.prompt}\n\nReturn your findings (most severe first). Be precise: file paths relative to the repo, line numbers, quoted code. No speculation without evidence; if unsure, say so in evidence and lower the severity.`, { label: `find:${d.key}`, phase: 'Find', schema: FINDINGS }),
  (res, d) => {
    if (!res) return null
    const toCheck = d.key === 'judge' || d.key === 'bytes' ? [] : res.findings.filter((f) => f.severity !== 'low')
    return parallel(toCheck.map((f) => () => agent(`${CONTEXT}\n## Adversarial check\nA reviewer (dimension "${d.key}") reported this finding. Your job is to REFUTE it if you can: re-read the code yourself, reproduce it yourself (scripts under /root/makefun/review/verify/), check whether it is actually reachable in play and whether the "bug" is intended behaviour. Default to refuted=true if you cannot confirm it. If it is real but the fix is wrong, too costly in bytes, or would break something, give a corrected_fix.\n\nFinding:\n${JSON.stringify(f, null, 1)}`, { label: `verify:${d.key}:${f.title.slice(0, 40)}`, phase: 'Verify', schema: VERDICT }).then((v) => ({ ...f, verdict: v }))))
      .then((checked) => ({ dimension: d.key, notes: res.notes, verified: checked.filter(Boolean), unverified: res.findings.filter((f) => !toCheck.includes(f)) }))
  },
)
return results.filter(Boolean)
