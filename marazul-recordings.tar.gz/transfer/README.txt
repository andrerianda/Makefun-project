MARAZUL recordings from the new session (container of session 4ea90a4a-482f-5f08-8e21-c0ce40f970dd), made 18 Nov 2026.

Contents
- transfer/recordings-entries.json: ~/.makefun/recordings.json of this machine; it holds exactly the three recordings
  01a1ee88-1e1e-7604-a051-7d512b4dc1e6 (shift 11, 12 sessions), 01a1eeb3-50fd-77f9-a850-75bce9f0e398 (shift 12, 14 sessions),
  01a1eee6-f1e3-777c-9e9c-8b025a480f1a (shift 13, 2 sessions).
- The 28 session files named in those entries' "files[].file", at their absolute paths
  (/root/.claude/projects/-home-user/4ea90a4a-482f-5f08-8e21-c0ce40f970dd/subagents/agent-*.jsonl), as they stand on this machine
  (raw, unredacted local files; transfer/SHA256SUMS.raw-files lists their sha256). The sha256 and bytes inside the entries are
  those of the SEALED documents, which record redacted (home paths, usernames, credentials), so they do not equal the raw files'
  hashes; the raw files are a few KB larger for that reason.
- One file changed after its recording was sealed: agent-a1e5258972dd67eef.jsonl (recording 01a1eeb3, sealed 13:37:24.580Z) got
  4 records at about 13:45 (a task notification and the agent's closing messages; no tool call, no repository change).
  transfer/agent-a1e5258972dd67eef.at-seal.jsonl is the same file cut before those 4 records, i.e. as it was at the seal.
- The parent (main orchestrator) session file at its absolute path
  /root/.claude/projects/-home-user/4ea90a4a-482f-5f08-8e21-c0ce40f970dd.jsonl, REDACTED: every API key, token, keypair
  and the owner's e-mail replaced with [REDACTED] / [email], so its bytes differ from the original. It began
  15 Nov 2026 (before the competition opened and before every recording); record left it out of all three
  recordings ("began before the recording"), so it is not one of the entry's transcripts.
Not included: ~/.makefun/credentials (none on this machine), keypairs, env files or any key.
The archive keeps absolute paths: extract with tar -xzPf (or without -P to get paths under ./root/...).
